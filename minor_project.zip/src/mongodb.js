const mongoose=require("mongoose")
// //these are the commands to connect your nodejs to mongodb database
mongoose.connect("mongodb://127.0.0.1:27017/EduHunt")
.then(()=>{
      console.log("mongodb connected");
})
.catch((error)=>{
    console.log("failed to connect",error);
})
//creating schema for the documents(records[row]) (collections are called table in mongodb)
const UserSchema = new mongoose.Schema({
    Username:{
        type:String,
        required:true
    },
    Location:{
        type:String,
        required:true
    },
    Subject:{
         type:String,
         required:true
     },
    Password:{
        type:String,
        required:true
    }
});
//define the collections
const collection=new mongoose.model("Collection1",UserSchema)
module.exports= collection