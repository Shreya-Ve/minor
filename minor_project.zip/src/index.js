const express = require("express");
const app = express();
const path = require("path");
const hbs=require("hbs");
const collection = require("./mongodb");

const templatePath = path.join(__dirname, "../template");
// app.use(express.static(__dirname + "/public"));
app.use(express.static("public"));
app.use(express.json());
app.set("view engine", "hbs");
app.set("views", templatePath);
app.use(express.urlencoded({ extended: false }));



app.get("/", (req, res) => {
  res.render("page");
});
app.get("/form", (req, res) => {
  res.render("form");
});
/*
app.post("/form", async (req, res) => {
  //extracting data from hbs form where user will give the info when he'll fill up form
  const data = {
    Username: req.body.name,
    Location: req.body.location,

    Subject: req.body.subject,
    password: req.body.password,
  };
  // to insert data and  give/fill data to mongodb
  await collection.insertMany([data]);

  res.render("result");
});

app.post("/form", async (req, res) => {
  try {
    const check = await collection.findOne({ username: req.body.username });
    if (check.password === req.body.password) {
      res.render("result");
    } else {
      res.send("Wrong Password!!");
    }
  } catch {
    res.send("Wrong Details!!");
  }
});
*/
app.post("/form", async (req, res) => {
  const data = {

    Username: req.body.name, 
    Location: req.body.location,
    Subject: req.body.subject,
    password: req.body.password,
  };
  try {
    const check = await collection.findOne({ username: req.body.username });
    if (check.password === req.body.password) 
      {
      // If password matches, insert the data and render the result page
      await collection.insertMany([data]);
      res.render("result");
       } 
      else {
      return res.send("Wrong Password!!");
       }
  } catch {
    return res.send("Wrong Details!!");
  }
   
})


app.listen(8000, () => {
  console.log("port connected");
});
