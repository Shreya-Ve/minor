console.log("Adding form event listener");
const form = document.querySelector('form');
form.addEventListener('submit', (event) => {
  console.log("Form submitted");
  event.preventDefault();
  console.log("Prevented default form submission behavior");
});
