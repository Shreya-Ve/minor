const express = require("express")
const path = require("path")
const app = express()
const hbs = require("hbs")
const LogInCollection = require("./mongo")
const port = process.env.PORT || 3000
app.use(express.json())

app.use(express.urlencoded({ extended: false }))

const tempelatePath = path.join(__dirname, '../tempelates')
const publicPath = path.join(__dirname, '../public')
console.log(publicPath);

app.set('view engine', 'hbs')
app.set('views', tempelatePath)
app.use(express.static(publicPath))

app.get('/', (req, res) => {
    res.render('page')
})
app.get('/form', (req, res) => {
    res.render('form')
})
app.get('/result', (req, res) => {
    console.log('Result page requested');
    res.render('result')
})

app.post('/form', async (req, res) => {
    console.log("Form submitted");
    const data = {
        name: req.body.name,
        location:req.body.location,
        subject:req.body.subject,
        password: req.body.password
    }

    try {
        const checking = await LogInCollection.findOne({ name: req.body.name })
        if (checking) {
            if (checking.password === req.body.password) {
                return res.redirect('/result');
            } else {
                await LogInCollection.insertMany([data])
                return res.redirect('/result');
            }
        } else {
            await LogInCollection.insertMany([data])
            return res.redirect('/result');
        }
    } catch (err) {
        console.error(err);
        console.log("An error occurred");
        res.send("An error occurred");
    }
    
})

app.listen(port, () => {
    console.log('port connected');
})